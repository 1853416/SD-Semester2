package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_Doctor_Login extends AppCompatActivity {

    private Button btn_Login;
    private Button btn_Register;
    private Button btn_Forgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        btn_Login = findViewById(R.id.B_A_DoctorLogin_Login);
        btn_Register = findViewById(R.id.B_A_DoctorLogin_Register);
        btn_Forgot = findViewById(R.id.B_A_DoctorLogin_Forget);

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DoctorLogin();
            }
        });
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DoctorRegister();
            }
        });
        btn_Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DoctorForgot();
            }
        });
    }

    private void DoctorLogin() {
        Intent intent = new Intent(this, Activity_Doctor.class);
        startActivity(intent);
    }

    private void DoctorRegister() {
        Intent intent = new Intent(this, Activity_Doctor_Register.class);
        startActivity(intent);
    }

    private void DoctorForgot() {

    }
}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_Patient_Login extends AppCompatActivity {

    private Button btn_Login;
    private Button btn_Register;
    private Button btn_Forgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);

        btn_Login = findViewById(R.id.B_A_PatientLogin_Login);
        btn_Register = findViewById(R.id.B_A_PatientLogin_Register);
        btn_Forgot = findViewById(R.id.B_A_PatientLogin_Forget);

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PatientLogin();
            }
        });
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PatientRegister();
            }
        });
        btn_Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PatientForgot();
            }
        });
    }

    private void PatientLogin() {
        Intent intent = new Intent(this, Activity_Patient.class);
        startActivity(intent);
    }

    private void PatientRegister() {
        Intent intent = new Intent(this, Activity_Patient_Register.class);
        startActivity(intent);
    }

    private void PatientForgot() {
    }


}
package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import com.google.android.material.textfield.TextInputLayout;

public class Activity_Doctor_Register extends AppCompatActivity {
    private AutoCompleteTextView tv_Fields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_register);

        tv_Fields = findViewById(R.id.TV_A_DoctorRegister_Fields);
        String []doctor_Fields
                = {
                "Practitioner",
                "OB/GYN",
                "Psychiatrist",
                "Dentist",
                "General Surgeon",
                "Dermatologist"};
        ArrayAdapter arrayAdapterDoctorFields
                = new ArrayAdapter(this,R.layout.doctor_feilds_dorpdown_item,doctor_Fields);
        tv_Fields.setAdapter(arrayAdapterDoctorFields);

    }
}